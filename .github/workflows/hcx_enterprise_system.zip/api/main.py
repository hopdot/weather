from fastapi import FastAPI
app=FastAPI()
@app.get('/')
def x(): return {'ok':1}